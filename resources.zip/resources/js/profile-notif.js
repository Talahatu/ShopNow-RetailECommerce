import $ from "jquery";

$(function () {
    $(".nav-link-profile").removeClass("active");
    $("#v-tabs-notif-tab-lg").addClass("active");
    $("#v-tabs-notif-tab").addClass("active");
});
