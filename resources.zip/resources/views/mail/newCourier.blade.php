<h1>Halo, {{ $data->name }}</h1>
<br>
<h3>Berikut merupakan username dan password untuk akun kurir baru anda!</h3>
<p>Username: {{ $data->username }}</p>
<p>Password: {{ $data->password }}</p>
<br>
<p>Jangan bagikan informasi tersebut kepada pihak manapun! Sekian terima kasih.</p>
